#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H

#include <stdbool.h>
#include <stdint.h>

#define Motor1_INA 12
#define Motor1_INB 13

#define Motor2_INA 23
#define Motor2_INB 22

#define Motor3_INA A2
#define Motor3_INB A3

#define Motor4_INA 25
#define Motor4_INB 24



extern void Motors_init();
extern void set_motor_direction(uint32_t MotorINAx,uint32_t MotorINBx,uint8_t direction);
extern void FreeBotStraight_Forward ();
extern void FreeBotStraight_Backward();
extern void FreeBotSide_Right();
extern void FreeBotSide_Left();
extern void FreeBotstop();
extern void FreeBotSide_DIAGONAL45();
extern void FreeBotSide_DIAGONAL135();
extern void FreeBotSide_DIAGONAL225();
extern void FreeBotSide_DIAGONAL315();
extern void FreeBotRotate_CLOCKWISE();
extern void FreeBotRotate_COUNTERCLOCKWISE();

#endif
